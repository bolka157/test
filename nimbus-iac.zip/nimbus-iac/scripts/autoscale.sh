#!/usr/bin/env bash
# Simple autoscaler for the retail tier, driven by Prometheus CPU data.
# Run it on the machine that has Terraform + Ansible:  ./scripts/autoscale.sh
# Needs: curl, jq, awk.  Tune with env vars, e.g.  MAX=8 UP=60 ./scripts/autoscale.sh
set -euo pipefail
cd "$(dirname "$0")/.."

MIN="${MIN:-2}"          # never go below this many retail VMs (normal day)
MAX="${MAX:-6}"          # never go above this many (peak day)
UP="${UP:-70}"           # scale out when average CPU % is above this
DOWN="${DOWN:-25}"       # scale in when average CPU % is below this
INTERVAL="${INTERVAL:-60}"

PROM="http://$(terraform -chdir=terraform output -raw mgmt_public_ip):9090"
QUERY='100 - (avg(rate(node_cpu_seconds_total{mode="idle",tier="retail"}[2m])) * 100)'

while true; do
  cpu=$(curl -fsS --data-urlencode "query=${QUERY}" "${PROM}/api/v1/query" \
        | jq -r '.data.result[0].value[1] // "0"')
  count=$(terraform -chdir=terraform output -raw retail_instance_count)
  echo "$(date +%T) retail cpu=${cpu}% instances=${count}"

  if awk "BEGIN{exit !(${cpu} > ${UP})}" && [ "${count}" -lt "${MAX}" ]; then
    echo "-> scaling out to $((count + 1))"
    ./scripts/scale.sh $((count + 1))
  elif awk "BEGIN{exit !(${cpu} < ${DOWN})}" && [ "${count}" -gt "${MIN}" ]; then
    echo "-> scaling in to $((count - 1))"
    ./scripts/scale.sh $((count - 1))
  fi
  sleep "${INTERVAL}"
done
