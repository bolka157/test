#!/usr/bin/env bash
# Set the size of the retail tier and configure any new VMs.
# Usage: ./scripts/scale.sh <retail_instance_count>
set -euo pipefail
cd "$(dirname "$0")/.."

count="${1:?usage: scale.sh <retail_instance_count>}"

# *.auto.tfvars is loaded automatically, so a later plain "terraform apply"
# keeps this size instead of snapping back to the default.
echo "retail_instance_count = ${count}" > terraform/scale.auto.tfvars

terraform -chdir=terraform apply -auto-approve
# New VMs get configured; the mgmt VM refreshes its Prometheus targets.
(cd ansible && ansible-playbook site.yml --limit "mgmt,retail_app")
