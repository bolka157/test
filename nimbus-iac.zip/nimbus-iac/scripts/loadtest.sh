#!/usr/bin/env bash
# Generate synthetic call traffic against one client's load balancer.
# Usage: ./scripts/loadtest.sh retail|bank [requests] [concurrency] [work]
set -euo pipefail
cd "$(dirname "$0")/.."

target="${1:?usage: loadtest.sh retail|bank [requests] [concurrency] [work]}"
requests="${2:-5000}"
concurrency="${3:-50}"
work="${4:-200000}"

ip=$(terraform -chdir=terraform output -raw "${target}_lb_ip")
command -v ab >/dev/null || sudo apt-get install -y apache2-utils

echo "Load test: ${requests} requests, ${concurrency} concurrent, work=${work} -> http://${ip}/call"
ab -n "${requests}" -c "${concurrency}" "http://${ip}/call?work=${work}"
