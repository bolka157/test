#!/usr/bin/env python3
"""Stand-in for a call-handling service. Synthetic data only.

GET /health          -> {"status": "ok"}
GET /call?work=N     -> burns CPU (N hash rounds), stores a fake 4 KB
                        "recording" in DATA_DIR and logs the event to syslog.
"""
import hashlib
import json
import logging
import logging.handlers
import os
import secrets
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

CLIENT = os.environ.get("CLIENT_NAME", "unknown")
DATA_DIR = os.environ.get("DATA_DIR", "/tmp")
PORT = int(os.environ.get("PORT", "8080"))
MAX_WORK = 2_000_000

log = logging.getLogger("nimbus-call")
log.setLevel(logging.INFO)
_handler = logging.handlers.SysLogHandler(address="/dev/log")
_handler.setFormatter(logging.Formatter("nimbus-call: %(message)s"))
log.addHandler(_handler)


def burn_cpu(rounds: int) -> None:
    digest = b"nimbus"
    for _ in range(rounds):
        digest = hashlib.sha256(digest).digest()


class Handler(BaseHTTPRequestHandler):
    def _send(self, code: int, body: dict) -> None:
        data = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):  # noqa: N802
        url = urlparse(self.path)
        if url.path == "/health":
            return self._send(200, {"status": "ok", "client": CLIENT})

        if url.path == "/call":
            try:
                work = int(parse_qs(url.query).get("work", ["50000"])[0])
            except ValueError:
                return self._send(400, {"error": "work must be an integer"})
            work = max(0, min(work, MAX_WORK))

            start = time.time()
            burn_cpu(work)
            call_id = secrets.token_hex(8)
            with open(os.path.join(DATA_DIR, f"call-{call_id}.rec"), "wb") as f:
                f.write(secrets.token_bytes(4096))  # synthetic recording
            ms = int((time.time() - start) * 1000)
            log.info("call handled client=%s id=%s duration_ms=%d", CLIENT, call_id, ms)
            return self._send(200, {"client": CLIENT, "call_id": call_id, "duration_ms": ms})

        self._send(404, {"error": "not found"})

    def log_message(self, *args):  # silence default stderr access log
        pass


if __name__ == "__main__":
    log.info("starting client=%s port=%d data_dir=%s", CLIENT, PORT, DATA_DIR)
    ThreadingHTTPServer(("0.0.0.0", PORT), Handler).serve_forever()
