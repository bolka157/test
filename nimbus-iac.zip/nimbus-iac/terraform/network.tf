# One VPC, three tiers. Isolation between bank and retail is enforced by
# network ACLs on the VPC router. ACLs are evaluated lowest rule number first
# and everything not allowed is denied.

locals {
  tier_cidr = {
    bank   = cidrsubnet(var.vpc_cidr, 8, 1)
    retail = cidrsubnet(var.vpc_cidr, 8, 2)
    mgmt   = cidrsubnet(var.vpc_cidr, 8, 3)
  }

  everywhere = "0.0.0.0/0"

  # client tier => the client tier it must never talk to
  client_tiers = {
    bank   = "retail"
    retail = "bank"
  }
}

resource "cloudstack_vpc" "nimbus" {
  name         = "nimbus-vpc"
  display_text = "Nimbus prototype VPC"
  cidr         = var.vpc_cidr
  vpc_offering = var.vpc_offering
  zone         = var.zone
  project      = var.project_name
}

resource "cloudstack_network_acl" "tier" {
  for_each    = local.tier_cidr
  name        = "nimbus-${each.key}-acl"
  description = "ACL for the ${each.key} tier"
  vpc_id      = cloudstack_vpc.nimbus.id
  project     = var.project_name
}

resource "cloudstack_network" "tier" {
  for_each         = local.tier_cidr
  name             = "nimbus-${each.key}"
  display_text     = "Nimbus ${each.key} tier"
  cidr             = each.value
  network_offering = var.network_offering
  zone             = var.zone
  vpc_id           = cloudstack_vpc.nimbus.id
  acl_id           = cloudstack_network_acl.tier[each.key].id
  project          = var.project_name
}

# ---- Bank and retail tiers (identical rules, mirrored deny) ----------------
resource "cloudstack_network_acl_rule" "client" {
  for_each = local.client_tiers
  acl_id   = cloudstack_network_acl.tier[each.key].id

  # ingress
  rule {
    rule_number  = 10
    action       = "allow"
    cidr_list    = [local.tier_cidr["mgmt"]]
    protocol     = "tcp"
    ports        = ["22", "9100"]
    traffic_type = "ingress"
    description  = "SSH and metrics scraping from the management tier"
  }
  rule {
    rule_number  = 20
    action       = "deny"
    cidr_list    = [local.tier_cidr[each.value]]
    protocol     = "all"
    traffic_type = "ingress"
    description  = "Client separation: no traffic from the other client"
  }
  rule {
    rule_number  = 30
    action       = "allow"
    cidr_list    = [local.everywhere]
    protocol     = "tcp"
    ports        = ["8080"]
    traffic_type = "ingress"
    description  = "Call-handling service (reached through the load balancer)"
  }

  # egress
  rule {
    rule_number  = 110
    action       = "deny"
    cidr_list    = [local.tier_cidr[each.value]]
    protocol     = "all"
    traffic_type = "egress"
    description  = "Client separation: no traffic to the other client"
  }
  rule {
    rule_number  = 120
    action       = "allow"
    cidr_list    = [local.tier_cidr["mgmt"]]
    protocol     = "tcp"
    ports        = ["514"]
    traffic_type = "egress"
    description  = "Syslog to the central log server"
  }
  rule {
    rule_number  = 130
    action       = "allow"
    cidr_list    = [local.everywhere]
    protocol     = "tcp"
    ports        = ["80", "443"]
    traffic_type = "egress"
    description  = "Package installs (tighten after provisioning)"
  }
  rule {
    rule_number  = 140
    action       = "allow"
    cidr_list    = [local.everywhere]
    protocol     = "udp"
    ports        = ["53", "123"]
    traffic_type = "egress"
    description  = "DNS and time sync"
  }
}

# ---- Management tier --------------------------------------------------------
resource "cloudstack_network_acl_rule" "mgmt" {
  acl_id = cloudstack_network_acl.tier["mgmt"].id

  rule {
    rule_number  = 10
    action       = "allow"
    cidr_list    = [var.admin_cidr]
    protocol     = "tcp"
    ports        = ["22", "3000", "9090"]
    traffic_type = "ingress"
    description  = "Admin access: SSH, Grafana, Prometheus"
  }
  rule {
    rule_number  = 20
    action       = "allow"
    cidr_list    = [local.tier_cidr["bank"], local.tier_cidr["retail"]]
    protocol     = "tcp"
    ports        = ["514"]
    traffic_type = "ingress"
    description  = "Syslog from the client tiers"
  }
  rule {
    rule_number  = 110
    action       = "allow"
    cidr_list    = [local.tier_cidr["bank"], local.tier_cidr["retail"]]
    protocol     = "tcp"
    ports        = ["22", "9100"]
    traffic_type = "egress"
    description  = "SSH jump host and metrics scraping"
  }
  rule {
    rule_number  = 120
    action       = "allow"
    cidr_list    = [local.everywhere]
    protocol     = "tcp"
    ports        = ["80", "443"]
    traffic_type = "egress"
    description  = "Package installs and container images"
  }
  rule {
    rule_number  = 130
    action       = "allow"
    cidr_list    = [local.everywhere]
    protocol     = "udp"
    ports        = ["53", "123"]
    traffic_type = "egress"
    description  = "DNS and time sync"
  }
}
