resource "local_file" "ansible_inventory" {
  filename        = "${path.module}/../ansible/inventory.ini"
  file_permission = "0640"
  content = templatefile("${path.module}/inventory.tftpl", {
    ssh_user        = var.ssh_user
    ssh_private_key = pathexpand(var.ssh_private_key_path)
    mgmt_public_ip  = cloudstack_ipaddress.mgmt.ip_address
    mgmt_private_ip = cloudstack_instance.mgmt.ip_address
    bank            = { for k, v in local.app_instances : k => cloudstack_instance.app[k].ip_address if v.tier == "bank" }
    retail          = { for k, v in local.app_instances : k => cloudstack_instance.app[k].ip_address if v.tier == "retail" }
  })

  depends_on = [cloudstack_port_forward.mgmt, cloudstack_loadbalancer_rule.app, cloudstack_disk.bank_data]
}
