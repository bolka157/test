terraform {
  required_version = ">= 1.5"

  required_providers {
    cloudstack = {
      source  = "cloudstack/cloudstack"
      version = "~> 0.5"
    }
    local = {
      source  = "hashicorp/local"
      version = "~> 2.5"
    }
  }
}

# Credentials come from environment variables, never from files:
#   export CLOUDSTACK_API_URL=https://educloud.fontysict.nl/client/api
#   export CLOUDSTACK_API_KEY=...
#   export CLOUDSTACK_SECRET_KEY=...
provider "cloudstack" {}
