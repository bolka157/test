# Public IPs: one load-balanced IP per client, one for management access.

resource "cloudstack_ipaddress" "lb" {
  for_each = local.tiers
  vpc_id   = cloudstack_vpc.nimbus.id
  project  = var.project_name
}

resource "cloudstack_ipaddress" "mgmt" {
  vpc_id  = cloudstack_vpc.nimbus.id
  project = var.project_name
}

resource "cloudstack_loadbalancer_rule" "app" {
  for_each      = local.tiers
  name          = "nimbus-${each.key}-lb"
  description   = "Load balancer for the ${each.key} call-handling service"
  ip_address_id = cloudstack_ipaddress.lb[each.key].id
  network_id    = cloudstack_network.tier[each.key].id
  algorithm     = "roundrobin"
  public_port   = 80
  private_port  = 8080
  member_ids    = [for k, v in local.app_instances : cloudstack_instance.app[k].id if v.tier == each.key]
  project       = var.project_name
}

# SSH (jump host), Grafana and Prometheus on the management VM.
# The management ACL only lets var.admin_cidr in.
resource "cloudstack_port_forward" "mgmt" {
  ip_address_id = cloudstack_ipaddress.mgmt.id
  project       = var.project_name

  forward {
    protocol           = "tcp"
    private_port       = 22
    public_port        = 22
    virtual_machine_id = cloudstack_instance.mgmt.id
  }
  forward {
    protocol           = "tcp"
    private_port       = 3000
    public_port        = 3000
    virtual_machine_id = cloudstack_instance.mgmt.id
  }
  forward {
    protocol           = "tcp"
    private_port       = 9090
    public_port        = 9090
    virtual_machine_id = cloudstack_instance.mgmt.id
  }
}
