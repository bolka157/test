output "bank_lb_ip" {
  value = cloudstack_ipaddress.lb["bank"].ip_address
}

output "retail_lb_ip" {
  value = cloudstack_ipaddress.lb["retail"].ip_address
}

output "mgmt_public_ip" {
  value = cloudstack_ipaddress.mgmt.ip_address
}

output "retail_instance_count" {
  value = var.retail_instance_count
}

output "urls" {
  value = {
    bank_service   = "http://${cloudstack_ipaddress.lb["bank"].ip_address}/health"
    retail_service = "http://${cloudstack_ipaddress.lb["retail"].ip_address}/health"
    grafana        = "http://${cloudstack_ipaddress.mgmt.ip_address}:3000"
    prometheus     = "http://${cloudstack_ipaddress.mgmt.ip_address}:9090"
  }
}
