variable "project_name" {
  type        = string
  description = "CloudStack project that holds the whole environment."
  default     = "nimbus"
}

variable "zone" {
  type        = string
  description = "CloudStack zone name (cmk list zones filter=name)."
}

variable "vpc_cidr" {
  type        = string
  description = "CIDR of the VPC. Must be a /16 so the three tiers become /24s."
  default     = "10.10.0.0/16"
}

variable "vpc_offering" {
  type    = string
  default = "Default VPC offering"
}

variable "network_offering" {
  type        = string
  description = "Network offering for VPC tiers (cmk list networkofferings forvpc=true filter=name)."
  default     = "DefaultIsolatedNetworkOfferingForVpc"
}

variable "template" {
  type        = string
  description = "Ubuntu template name (cmk list templates templatefilter=executable filter=name)."
}

variable "service_offering" {
  type        = string
  description = "Compute offering for the application VMs."
}

variable "mgmt_service_offering" {
  type        = string
  description = "Compute offering for the management VM. Empty = same as service_offering."
  default     = ""
}

variable "data_disk_offering" {
  type        = string
  description = "Disk offering for the bank data volumes."
}

variable "data_disk_size" {
  type        = number
  description = "Size in GB. Only set this when the disk offering is a custom-size offering."
  default     = null
}

variable "ssh_public_key_path" {
  type    = string
  default = "~/.ssh/id_ed25519.pub"
}

variable "ssh_private_key_path" {
  type    = string
  default = "~/.ssh/id_ed25519"
}

variable "ssh_user" {
  type    = string
  default = "ubuntu"
}

variable "admin_cidr" {
  type        = string
  description = "CIDR allowed to reach SSH, Grafana and Prometheus (your public IP as x.x.x.x/32)."

  validation {
    condition     = var.admin_cidr != "0.0.0.0/0"
    error_message = "Do not open the management tier to the whole internet. Use your own IP/32 or the Fontys VPN range."
  }
}

variable "bank_instance_count" {
  type    = number
  default = 2
}

variable "retail_instance_count" {
  type        = number
  description = "Normal-day size of the retail tier. scripts/scale.sh and scripts/autoscale.sh change this."
  default     = 2
}
