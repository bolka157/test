locals {
  tiers = {
    bank   = var.bank_instance_count
    retail = var.retail_instance_count
  }

  # e.g. { "bank-app-1" = {tier="bank"}, "retail-app-1" = {tier="retail"}, ... }
  # Keyed by name so adding retail-app-3 never touches the existing VMs.
  app_instances = merge([
    for tier, count in local.tiers : {
      for i in range(count) : "${tier}-app-${i + 1}" => { tier = tier }
    }
  ]...)
}

resource "cloudstack_ssh_keypair" "nimbus" {
  name       = "nimbus-key"
  public_key = file(pathexpand(var.ssh_public_key_path))
  project    = var.project_name
}

# Spread the VMs of a tier over different hosts, so one host failure does not
# take the whole tier down. (One zone only: real multi-AZ needs a second zone.)
resource "cloudstack_affinity_group" "spread" {
  for_each    = local.tiers
  name        = "nimbus-${each.key}-spread"
  description = "Keep ${each.key} VMs on different hosts"
  type        = "host anti-affinity"
  project     = var.project_name
}

resource "cloudstack_instance" "app" {
  for_each             = local.app_instances
  name                 = "nimbus-${each.key}"
  service_offering     = var.service_offering
  template             = var.template
  zone                 = var.zone
  network_id           = cloudstack_network.tier[each.value.tier].id
  keypair              = cloudstack_ssh_keypair.nimbus.name
  affinity_group_names = [cloudstack_affinity_group.spread[each.value.tier].name]
  project              = var.project_name
  expunge              = true
}

resource "cloudstack_instance" "mgmt" {
  name             = "nimbus-mgmt"
  service_offering = coalesce(var.mgmt_service_offering, var.service_offering)
  template         = var.template
  zone             = var.zone
  network_id       = cloudstack_network.tier["mgmt"].id
  keypair          = cloudstack_ssh_keypair.nimbus.name
  project          = var.project_name
  expunge          = true
}

# Data volumes for the bank tier. Ansible encrypts them with LUKS using keys
# that are generated and held by Nimbus, not by the provider.
resource "cloudstack_disk" "bank_data" {
  for_each           = { for k, v in local.app_instances : k => v if v.tier == "bank" }
  name               = "nimbus-${each.key}-data"
  attach             = true
  disk_offering      = var.data_disk_offering
  size               = var.data_disk_size
  virtual_machine_id = cloudstack_instance.app[each.key].id
  zone               = var.zone
  project            = var.project_name
}
