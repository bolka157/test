# Nimbus prototype: Terraform + Ansible on EduCloud (CloudStack)

Builds the prototype from the project plan:

| Plan requirement | Where it is implemented |
|---|---|
| Separate environments for bank and retailer | One VPC, one tier per client, network ACLs deny traffic between them (`terraform/network.tf`) |
| Call-handling service behind a load balancer | `cloudstack_loadbalancer_rule` + `callservice` role (stand-in service) |
| Scale from normal to peak and back | `scripts/scale.sh` and `scripts/autoscale.sh` (Prometheus CPU driven) |
| Bank data encrypted with its own keys | LUKS volume per bank VM, keys generated on your machine (`encrypted_volume` role) |
| Central log that cannot be changed afterwards | rsyslog receiver on the mgmt VM, files made append-only (`logserver` role) |
| Survive a failure | Host anti-affinity groups + load balancer |
| Health dashboards and alerts | Prometheus + Grafana + alert rules (`monitoring` role) |
| Everything as code | `terraform apply` then `ansible-playbook site.yml` |

```
Internet
   |  :80 bank LB       :80 retail LB        :22/:3000/:9090 (admin_cidr only)
   v                    v                    v
+------- VPC 10.10.0.0/16 ------------------------------------+
| bank tier       | retail tier      | mgmt tier              |
| 10.10.1.0/24    | 10.10.2.0/24     | 10.10.3.0/24           |
| app x2 + LUKS   | app x2..6        | jump host, Prometheus, |
| volume          |                  | Grafana, log server    |
+-----------------+------------------+------------------------+
   bank <-X-> retail (ACL deny)       logs: bank/retail -> mgmt :514
```

## 1. Prerequisites (on the machine you run this from)

```bash
sudo apt update && sudo apt install -y ansible jq curl
# Terraform (HashiCorp apt repo)
wget -O- https://apt.releases.hashicorp.com/gpg | sudo gpg --dearmor -o /usr/share/keyrings/hashicorp-archive-keyring.gpg
echo "deb [signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] https://apt.releases.hashicorp.com $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/hashicorp.list
sudo apt update && sudo apt install -y terraform
# SSH key pair for the VMs (skip if you have one)
ssh-keygen -t ed25519 -f ~/.ssh/id_ed25519 -N ""
```

## 2. Credentials (environment variables only, never in files)

Create new API keys first (the old ones were shared in chat), then:

```bash
export CLOUDSTACK_API_URL=https://educloud.fontysict.nl/client/api
export CLOUDSTACK_API_KEY=<api key>
export CLOUDSTACK_SECRET_KEY=<secret key>
```

## 3. Configure

```bash
cd terraform
cp terraform.tfvars.example terraform.tfvars
```

Fill in the values. The commands to look them up with `cmk` are at the top of the file. For the project, `cmk list projects` shows `nimbus`.

## 4. Build

```bash
terraform init
terraform plan
terraform apply            # creates VPC, VMs, LBs, ACLs and ../ansible/inventory.ini

cd ../ansible
ansible-galaxy collection install -r requirements.yml
ansible-playbook site.yml
```

Terraform prints the URLs. Check:

```bash
curl http://<bank_lb_ip>/health
curl http://<retail_lb_ip>/health
```

Grafana: `http://<mgmt_public_ip>:3000` (user `admin`, password in `ansible/secrets/grafana_admin.pass`).
Add a dashboard with *Dashboards > New > Import > ID 1860* (Node Exporter Full). Alerts are visible at `http://<mgmt_public_ip>:9090/alerts`.

## 5. Test against the requirements (SQ5)

| Test | How |
|---|---|
| Scaling | `./scripts/autoscale.sh` in one terminal, `./scripts/loadtest.sh retail 20000 100` in another. Watch the instance count in the autoscaler output and CPU in Grafana. |
| Manual peak / normal | `./scripts/scale.sh 6` then `./scripts/scale.sh 2` |
| Failure | Stop one app VM (`cmk stop virtualmachine id=<id>`) while load-testing. The LB keeps serving and the `InstanceDown` alert fires. |
| Client separation | SSH to a bank VM via the mgmt VM and try `curl http://<retail-vm-ip>:8080/health`. It must time out. The reverse too. |
| Encryption | On a bank VM: `lsblk -f` shows `crypto_LUKS` on the data disk, and `sudo cryptsetup isLuks /dev/vdb` succeeds. |
| Central logging | On mgmt: `ls /var/log/nimbus/*`; `lsattr` shows the `a` flag; try `sudo sed -i s/x/y/ <file>` and see it fail. |

## 6. Remove everything

```bash
cd terraform && terraform destroy
```

## Limitations (mention these in the report)

- **One zone only.** CloudStack zones are the availability zones. This prototype spreads VMs over hosts (anti-affinity), but a real multi-AZ test needs a second zone.
- **Autoscaling is script-driven.** The Terraform provider cannot manage CloudStack's native autoscale groups, so `autoscale.sh` implements the scale-out/in loop. Scale-out takes a few minutes (VM boot + Ansible), more than the 10 minute target if the tier is large.
- **Key handling.** LUKS keys are generated on the Ansible machine and stored on each VM's root disk so the volume mounts at boot. This protects the data volume (and its snapshots) at storage level, but not against someone who gets into the VM. Production would fetch keys from Vault or a cloud KMS.
- **Log integrity.** Append-only attributes make tampering hard, but root on the log server can still remove them. Production would use object-lock storage or a SIEM. Syslog is plain TCP; use TLS in the next iteration.
- **Egress.** Ports 80/443 to the internet are open for package installs. Tighten the egress rules after provisioning.
- **Stand-in application.** `callservice.py` simulates call handling (CPU work + a fake 4 KB recording per call). Swap in Asterisk later by replacing the `callservice` role.
